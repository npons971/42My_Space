import time

from ftmsg.discovery import BroadcastDiscovery, DiscoveredChannel, resolve_local_ip


def test_resolve_local_ip():
    ip = resolve_local_ip()
    assert ip != ""
    parts = ip.split(".")
    assert len(parts) == 4


def test_discovered_channel_ttl():
    ch = DiscoveredChannel(
        name="test", host_ip="127.0.0.1", host_port=1234,
        is_public=True, user_count=1, max_users=5,
        last_seen=time.time(),
    )
    assert ch.name == "test"

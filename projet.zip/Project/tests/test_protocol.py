import pytest

from ftmsg.protocol import encode_frame, decode_frame, MAX_FRAME_SIZE
import struct


def test_encode_decode_roundtrip():
    frame = {"type": "MESSAGE", "payload": "hello"}
    data = encode_frame(frame)
    length = struct.unpack("!I", data[:4])[0]
    assert length == len(data) - 4
    decoded = decode_frame(data[4:])
    assert decoded == frame


def test_encode_frame_too_large():
    big = {"x": "A" * (MAX_FRAME_SIZE + 1)}
    with pytest.raises(ValueError, match="frame too large"):
        encode_frame(big)

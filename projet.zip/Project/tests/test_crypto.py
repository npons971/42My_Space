import pytest

from ftmsg.crypto import (
    encrypt,
    decrypt,
    encrypt_symmetric,
    decrypt_symmetric,
    generate_room_key,
    generate_or_load_encryption_keypair,
)


def test_asymmetric_roundtrip():
    priv, pub = generate_or_load_encryption_keypair()
    plaintext = b"secret message"
    ciphertext = encrypt(plaintext, pub)
    recovered = decrypt(ciphertext, priv)
    assert recovered == plaintext


def test_symmetric_roundtrip():
    key = generate_room_key()
    plaintext = "hello world"
    ciphertext = encrypt_symmetric(plaintext, key)
    recovered = decrypt_symmetric(ciphertext, key)
    assert recovered == plaintext


def test_symmetric_bad_key_fails():
    key = generate_room_key()
    ciphertext = encrypt_symmetric("test", key)
    bad_key = generate_room_key()
    with pytest.raises(Exception):
        decrypt_symmetric(ciphertext, bad_key)

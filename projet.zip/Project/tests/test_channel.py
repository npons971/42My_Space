import asyncio

import pytest

from ftmsg.channel import ChannelServer, ChannelClient, validate_login


@pytest.mark.asyncio
async def test_channel_server_start_stop():
    server = ChannelServer("test", "", 5, True, "host")
    port = await server.start()
    assert port > 0
    await server.stop()


@pytest.mark.asyncio
async def test_client_join_and_message():
    received = []
    def on_msg(sender, payload, ts):
        received.append((sender, payload))

    server = ChannelServer("test", "", 5, True, "host", on_message=on_msg)
    port = await server.start()

    client = ChannelClient("alice", on_message=on_msg)
    status, detail = await client.connect("127.0.0.1", port, "", "alice")
    assert status == "connected"

    await client.send_message("hello")
    await asyncio.sleep(0.3)

    await client.disconnect()
    await server.stop()

    assert any(p == "hello" for s, p in received)


@pytest.mark.asyncio
async def test_rate_limit():
    server_received = []
    def on_srv(sender, payload, ts):
        server_received.append(payload)

    server = ChannelServer("test", "", 5, True, "host", on_message=on_srv)
    port = await server.start()

    client = ChannelClient("spammer")
    status, _ = await client.connect("127.0.0.1", port, "", "spammer")
    assert status == "connected"

    for i in range(15):
        await client.send_message(f"msg{i}")
        await asyncio.sleep(0.01)

    await asyncio.sleep(0.3)
    await client.disconnect()
    await server.stop()

    assert len(server_received) == 10  # rate limited


@pytest.mark.asyncio
async def test_kick():
    server = ChannelServer("test", "", 5, True, "host")
    port = await server.start()

    client = ChannelClient("alice")
    status, _ = await client.connect("127.0.0.1", port, "", "alice")
    assert status == "connected"

    ok = await server.kick("alice")
    assert ok

    await asyncio.sleep(0.5)
    assert not client._connected
    await server.stop()


@pytest.mark.asyncio
async def test_ban_prevents_rejoin():
    server = ChannelServer("test", "", 5, True, "host")
    port = await server.start()

    client = ChannelClient("alice")
    status, _ = await client.connect("127.0.0.1", port, "", "alice")
    assert status == "connected"

    await server.ban("alice")
    await asyncio.sleep(0.5)
    assert not client._connected

    client2 = ChannelClient("alice")
    status2, detail2 = await client2.connect("127.0.0.1", port, "", "alice")
    assert status2 == "rejected"
    assert detail2 == "banned"

    await server.stop()


def test_validate_login():
    assert validate_login("alice") is None
    assert validate_login("") == "login required"
    assert validate_login("a" * 21) is not None
    assert validate_login("bob!") is not None

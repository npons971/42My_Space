from __future__ import annotations

import json
import logging
import socket
import struct
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from .channel import ChannelInfo

logger = logging.getLogger(__name__)


BROADCAST_PORT = 42069
BEACON_INTERVAL = 3.0
MCAST_GROUP = "239.255.42.69"


def resolve_broadcast_addr() -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(1.0)
        sock.connect(("8.8.8.8", 80))
        local_ip = sock.getsockname()[0]
        sock.close()
        parts = local_ip.split(".")
        return f"{parts[0]}.{parts[1]}.{parts[2]}.255"
    except OSError:
        return "255.255.255.255"


def resolve_local_ip() -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(1.0)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except OSError:
        return "127.0.0.1"


@dataclass
class DiscoveredChannel:
    name: str
    host_ip: str
    host_port: int
    is_public: bool
    user_count: int
    max_users: int
    last_seen: float = 0.0
    campus_only: bool = False


class BroadcastDiscovery:
    def __init__(
        self,
        on_channel: Callable[[DiscoveredChannel], None] | None = None,
        on_channel_lost: Callable[[str], None] | None = None,
    ) -> None:
        self.local_ip = resolve_local_ip()
        self.broadcast_addr = resolve_broadcast_addr()
        self.on_channel = on_channel
        self.on_channel_lost = on_channel_lost

        self._channels: dict[str, DiscoveredChannel] = {}
        self._lock = threading.Lock()
        self._running = False
        self._listen_thread: threading.Thread | None = None
        self._beacon_thread: threading.Thread | None = None
        self._beacon_info: ChannelInfo | None = None
        self._own_channel_key: str | None = None
        self._listen_ready = threading.Event()
        self._listen_error: str | None = None

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._listen_ready.clear()
        self._listen_error = None
        self._listen_thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._listen_thread.start()
        if not self._listen_ready.wait(timeout=2.0):
            self._running = False
            raise RuntimeError(self._listen_error or f"discovery bind failed on port {BROADCAST_PORT}")

    def stop(self) -> None:
        self._running = False
        if self._listen_thread:
            self._listen_thread.join(timeout=2.0)
            self._listen_thread = None
        self._stop_beaconing()

    def start_beaconing(self, info: ChannelInfo) -> None:
        self._beacon_info = info
        self._own_channel_key = f"{info.host_ip}:{info.host_port}"
        if self._beacon_thread and self._beacon_thread.is_alive():
            return
        self._beacon_thread = threading.Thread(target=self._beacon_loop, daemon=True)
        self._beacon_thread.start()

    def _stop_beaconing(self) -> None:
        self._beacon_info = None
        self._own_channel_key = None
        self._beacon_thread = None

    def update_beacon(self, info: ChannelInfo) -> None:
        self._beacon_info = info

    def _purge_stale_channels(self) -> None:
        now = time.time()
        with self._lock:
            stale = [k for k, ch in self._channels.items() if now - ch.last_seen >= 10.0]
            for k in stale:
                ch = self._channels.pop(k, None)
                if ch and self.on_channel_lost:
                    self.on_channel_lost(ch.name)

    def get_channels(self) -> list[DiscoveredChannel]:
        self._purge_stale_channels()
        with self._lock:
            return list(self._channels.values())

    def _send_beacon(self, sock: socket.socket) -> None:
        if not self._beacon_info:
            return
        info = self._beacon_info
        packet = json.dumps({
            "type": "42MSG_BEACON",
            "channel_name": info.name,
            "host_ip": info.host_ip,
            "host_port": info.host_port,
            "is_public": info.is_public,
            "user_count": info.user_count,
            "max_users": info.max_users,
            "campus_only": info.campus_only,
            "version": 2,
        }, separators=(",", ":"))

        try:
            sock.sendto(packet.encode("utf-8"), (self.broadcast_addr, BROADCAST_PORT))
        except OSError:
            logger.debug("beacon sendto broadcast failed", exc_info=True)

        if self.local_ip != self.broadcast_addr:
            try:
                sock.sendto(packet.encode("utf-8"), (self.local_ip, BROADCAST_PORT))
            except OSError:
                logger.debug("beacon sendto local_ip failed", exc_info=True)

        try:
            sock.sendto(packet.encode("utf-8"), (MCAST_GROUP, BROADCAST_PORT))
        except OSError:
            logger.debug("beacon sendto multicast failed", exc_info=True)

    def _beacon_loop(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(1.0)

        try:
            while self._running and self._beacon_info:
                self._send_beacon(sock)
                time.sleep(BEACON_INTERVAL)
        finally:
            sock.close()

    def _listen_loop(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(1.0)

        try:
            sock.bind(("", BROADCAST_PORT))
        except OSError as exc:
            self._listen_error = str(exc)
            sock.close()
            return

        try:
            mreq = struct.pack("4sL", socket.inet_aton(MCAST_GROUP), socket.INADDR_ANY)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        except OSError:
            logger.debug("multicast join failed", exc_info=True)

        self._listen_ready.set()
        cleanup_counter = 0
        try:
            while self._running:
                try:
                    data, addr = sock.recvfrom(2048)
                except socket.timeout:
                    cleanup_counter += 1
                    if cleanup_counter >= 5:
                        cleanup_counter = 0
                        self._purge_stale_channels()
                    continue
                except OSError:
                    logger.debug("discovery recvfrom error", exc_info=True)
                    break

                try:
                    msg = json.loads(data.decode("utf-8"))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    continue

                if not isinstance(msg, dict) or msg.get("type") != "42MSG_BEACON":
                    continue

                if msg.get("version") != 2:
                    continue

                host_ip = str(msg.get("host_ip", addr[0]))
                host_port = int(msg.get("host_port", 0))
                if host_port == 0:
                    continue

                if host_ip == self.local_ip:
                    continue

                key = f"{host_ip}:{host_port}"
                if key == self._own_channel_key:
                    continue

                ch = DiscoveredChannel(
                    name=str(msg.get("channel_name", "")),
                    host_ip=host_ip,
                    host_port=host_port,
                    is_public=bool(msg.get("is_public", False)),
                    user_count=int(msg.get("user_count", 0)),
                    max_users=int(msg.get("max_users", 0)),
                    last_seen=time.time(),
                    campus_only=bool(msg.get("campus_only", False)),
                )

                with self._lock:
                    self._channels[key] = ch

                if self.on_channel:
                    self.on_channel(ch)

        finally:
            sock.close()
